﻿/* Connor Wolf
 * Equipment.cs
 * Assignment 1
 * Equipment interface
  */
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface Equipment
{
    void Equip();
    void Unequip();
}
