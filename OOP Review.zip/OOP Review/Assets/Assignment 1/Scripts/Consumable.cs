﻿/* Connor Wolf
 * Consumable.cs
 * Assignment 1
 * Consumable class
  */
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Consumable : Item, Equipment, Crafting
{
    private int enhancements;
    private int offense;
    private int defense;

    public Consumable(string name, int inOffense, int inDefense)
    {
        SetTitle(name);
        SetType("Consumable");
        defense = inDefense;
        offense = inOffense;
    }

    public void Dismantle()
    {
        Debug.Log("Dismantled enhancements for " + enhancements.ToString() + " Materia.");
        offense -= enhancements;
        defense -= enhancements;
        enhancements = 0;
    }

    public void EnhanceStrength(int level)
    {
        Debug.Log("Enhanced defense by " + level.ToString() + " points for a total of " 
            + level+defense.ToString() + " defense and " + level+offense.ToString() + " offense.");
        enhancements += level;
        offense += level;
        defense += level;
    }

    public void Equip()
    {
        Debug.Log("Equipped " + GetTitle() + ".");
    }

    public override void Examine()
    {
        Debug.Log("A consumable item called a " + GetTitle());
    }

    public void Unequip()
    {
        Debug.Log("Unequipped " + GetTitle() + ".");
    }
}
