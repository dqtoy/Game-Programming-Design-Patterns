﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemManager : MonoBehaviour
{
    private Item[] items = new Item[4];
    private Equipment[] equipment = new Equipment[4];
    private Weapon longSword;
    private Armor plateMail;
    private Weapon dagger;
    private Armor hide;
    private Consumable flashBang;

    // Start is called before the first frame update
    void Start()
    {
        longSword = new Weapon("Longsword", 15, 75);
        plateMail = new Armor("Plate Mail", 10, 5);
        dagger = new Weapon("Dagger", 5, 100);
        //hide = new Armor("Hide", 5, 15);
        flashBang = new Consumable("Flash Bang", 5, 50);

        items[0] = longSword;
        items[1] = plateMail;
        items[2] = dagger;
        //items[3] = hide;
        items[3] = flashBang;
        
        /*
        longSword.EnhanceStrength(5);
        longSword.Dismantle();
        longSword.Equip();
        longSword.Unequip();

        plateMail.EnhanceStrength(5);
        plateMail.Dismantle();
        plateMail.Equip();
        plateMail.Unequip();
        */
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            foreach(Item item in items)
            {
                item.Examine();
            }
        }

        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            foreach(Equipment equipment in items)
            {
                equipment.Equip();
            }
        }
    }
}
