﻿/* Connor Wolf
 * Crafting.cs
 * Assignment 1
 * Crafting interface
  */
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface Crafting
{
    void EnhanceStrength(int level);
    void Dismantle();
}
