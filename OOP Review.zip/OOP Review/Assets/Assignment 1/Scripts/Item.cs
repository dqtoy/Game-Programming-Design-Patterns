﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Item
{
    protected string title;
    protected string itemType;

    public string GetTitle() { return title; }
    public void SetTitle(string newTitle) { title = newTitle; }

    public string GetItemType() { return itemType; }
    public void SetType(string newType) { itemType= newType; }

    abstract public void Examine();
}
