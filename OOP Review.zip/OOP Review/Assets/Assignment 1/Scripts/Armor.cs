﻿/* Connor Wolf
 * Armor.cs
 * Assignment 1
 * Armor class
  */
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Armor : Item, Equipment, Crafting
{
    private int enhancements;
    private int defense;
    private int evasion;

    public Armor(string name, int inDefense, int inEvasion)
    {
        SetTitle(name);
        SetType("Armor");
        defense = inDefense;
        evasion = inEvasion;
    }

    public void Dismantle()
    {
        Debug.Log("Dismantled enhancements for " + enhancements.ToString() + " Materia.");
        defense -= enhancements;
        enhancements = 0;
    }

    public void EnhanceStrength(int level)
    {
        Debug.Log("Enhanced defense by " + level.ToString() + " points for a total of " + defense+level.ToString() + ".");
        enhancements += level;
        defense += level;
    }

    public void Equip()
    {
        Debug.Log("Equipped " + GetTitle() + ".");
    }

    public override void Examine()
    {
        Debug.Log("A piece of armor known as " + GetTitle() + ".");
    }

    public void Unequip()
    {
        Debug.Log("Unequipped " + GetTitle() + ".");
    }
}
