﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon : Item, Equipment, Crafting
{
    private int enhancements;
    private int offense;
    private int accuracy;

    public Weapon(string name, int inOffense, int inAccuracy)
    {
        SetTitle(name);
        SetType("Weapon");
        offense = inOffense;
        accuracy = inAccuracy;
    }

    public void Dismantle()
    {
        Debug.Log("Dismantled enhancements for " + enhancements.ToString() + " Materia.");
        offense -= enhancements;
        enhancements = 0;
    }

    public void EnhanceStrength(int level)
    {
        Debug.Log("Enhanced offense by " + level.ToString() + " points for a total of " + offense+level.ToString() + ".");
        enhancements += level;
        offense += level;
    }

    public void Equip()
    {
        Debug.Log("Equipped " + GetTitle() + ".");
    }

    public override void Examine()
    {
        Debug.Log("A weapon known as a " + GetTitle() + ".");
    }

    public void Unequip()
    {
        Debug.Log("Unequipped " + GetTitle() + ".");
    }
}
